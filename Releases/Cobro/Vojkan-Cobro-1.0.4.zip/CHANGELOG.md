## v1.0.4
- Changes for latest BroMaker update.
- Add announcer voiceline.

## v1.0.0
- Initial release